I'm not sure why you're reading this, but; Merry Christmas and Happy Holidays.
This is my favorite holiday, and hosting an event around it
is more incredibly fun and exciting. Thank you for being here!
- James P. 2020